import inspect
from cleanroom.interpreter_v2 import interpret, View, Standing

def test_no_original_continuity_import():
    source=inspect.getsource(__import__("cleanroom.interpreter_v2", fromlist=["*"]))
    assert "cc_apparatus.continuity" not in source
    assert "BlindContinuityOperator" not in source

def test_no_answer_key_or_chamber_input():
    sig=str(inspect.signature(interpret)).lower()
    assert "answer" not in sig
    assert "chamber" not in sig

def test_missing_is_unresolved_not_rupture():
    r=interpret(completed=True, witnesses={"W_L":View(Standing.INSUFFICIENT,"CONTINUITY_SUPPORT")})
    assert r.standing.value=="UNRESOLVED"
    assert r.relation is None

def test_contradiction_is_rupture():
    r=interpret(completed=True, witnesses={"W_L":View(Standing.CONTRADICTED,"CONTINUITY_SUPPORT")})
    assert r.relation=="RUPTURE"

def test_constraint_delta_without_dependency_rule_abstains():
    r=interpret(completed=True, witnesses={"W_K":View(Standing.AUTHENTICATED,"CONSTRAINT_DELTA_IDENTITY_DEPENDENCE_UNESTABLISHED")})
    assert r.standing.value=="UNRESOLVED"
    assert r.relation is None
