from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple, Mapping

class Standing(str, Enum):
    AUTHENTICATED="AUTHENTICATED"
    CONTRADICTED="CONTRADICTED"
    INSUFFICIENT="INSUFFICIENT"
    NOT_APPLICABLE="NOT_APPLICABLE"

class Epistemic(str, Enum):
    RESOLVED="RESOLVED"
    UNRESOLVED="UNRESOLVED"

@dataclass(frozen=True)
class View:
    standing: Standing
    claim_type: str

@dataclass(frozen=True)
class CleanResult:
    standing: Epistemic
    relation: Optional[str]
    reasons: Tuple[str,...]

def interpret(*, completed: bool, witnesses: Mapping[str, View]) -> CleanResult:
    # Clean-room decision table derived only from frozen semantic obligations.
    contradicted = sorted(k for k,v in witnesses.items() if v.standing is Standing.CONTRADICTED)
    missing = sorted(k for k,v in witnesses.items() if v.standing is Standing.INSUFFICIENT)

    if contradicted:
        return CleanResult(Epistemic.RESOLVED, "RUPTURE",
                           ("authenticated_contradiction:" + ",".join(contradicted),))

    if not completed:
        return CleanResult(Epistemic.UNRESOLVED, None, ("transition_incomplete",))

    if missing:
        return CleanResult(Epistemic.UNRESOLVED, None,
                           ("causal_support_insufficient:" + ",".join(missing),))

    claims = frozenset(v.claim_type for v in witnesses.values()
                       if v.standing is Standing.AUTHENTICATED)

    if "CONSTRAINT_DELTA_IDENTITY_DEPENDENCE_UNESTABLISHED" in claims:
        return CleanResult(Epistemic.UNRESOLVED, None,
                           ("identity_dependence_unestablished",))

    if "BRANCHING_SUCCESSION" in claims:
        return CleanResult(Epistemic.RESOLVED, "SUCCESSION",
                           ("branching_successor_relation",))

    if "LAWFUL_AUTHORITY_MUTATION" in claims:
        return CleanResult(Epistemic.RESOLVED, "MUTATION",
                           ("lawful_authority_mutation",))

    return CleanResult(Epistemic.RESOLVED, "PERSISTENCE",
                       ("completed_supported_continuity",))
