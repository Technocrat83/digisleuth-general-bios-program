import json, sys
from pathlib import Path

ORIGINAL = Path(__file__).resolve().parent.parent / "CC_BLIND_EVALUATION_APPARATUS_v0_1"
sys.path.insert(0, str(ORIGINAL))

from cc_apparatus.fixture_generation import generate_fixture
from cc_apparatus.authentication import WitnessAuthenticationSurface
from cleanroom.interpreter_v2 import interpret, View, Standing

CHAMBERS=[f"CC_F{i:02d}" for i in range(1,13)]

def main():
    auth = WitnessAuthenticationSurface()
    rows=[]
    for cid in CHAMBERS:
        f=generate_fixture(cid)
        aw=auth.authenticate_vector(f.witnesses)
        views={k:View(Standing(v.standing.value), v.claim_type) for k,v in aw.items()}
        r=interpret(completed=f.residue.completed, witnesses=views)
        observed="UNRESOLVED" if r.standing.value=="UNRESOLVED" else r.relation
        rows.append({
            "chamber_id":cid,
            "expected":f.answer_key,
            "observed":observed,
            "pass":observed==f.answer_key,
            "standing":r.standing.value,
            "reasons":list(r.reasons),
        })
    print(json.dumps(rows, indent=2))
if __name__=="__main__":
    main()
